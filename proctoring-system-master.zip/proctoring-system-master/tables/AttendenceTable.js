
/*
regdNo        | varchar(20) | NO   | PRI | NULL    |       |
1August       | varchar(3)  | YES  |     | NULL    |       |
1September    | varchar(3)  | YES  |     | NULL    |       |
1October      | varchar(3)  | YES  |     | NULL    |       |
1January      | varchar(3)  | YES  |     | NULL    |       |
1February     | varchar(3)  | YES  |     | NULL    |       |
1March        | varchar(3)  | YES  |     | NULL    |       |
1FirstSemEnd  | varchar(3)  | YES  |     | NULL    |       |
1SecondSemEnd | varchar(3)  | YES  |     | NULL    |       |
2August       | varchar(3)  | YES  |     | NULL    |       |
2September    | varchar(3)  | YES  |     | NULL    |       |
2October      | varchar(3)  | YES  |     | NULL    |       |
2January      | varchar(3)  | YES  |     | NULL    |       |
2February     | varchar(3)  | YES  |     | NULL    |       |
2March        | varchar(3)  | YES  |     | NULL    |       |
2FirstSemEnd  | varchar(3)  | YES  |     | NULL    |       |
2SecondSemEnd | varchar(3)  | YES  |     | NULL    |       |
3August       | varchar(3)  | YES  |     | NULL    |       |
3September    | varchar(3)  | YES  |     | NULL    |       |
3October      | varchar(3)  | YES  |     | NULL    |       |
3January      | varchar(3)  | YES  |     | NULL    |       |
3February     | varchar(3)  | YES  |     | NULL    |       |
3March        | varchar(3)  | YES  |     | NULL    |       |
3FirstSemEnd  | varchar(3)  | YES  |     | NULL    |       |
3SecondSemEnd | varchar(3)  | YES  |     | NULL    |       |
4August       | varchar(3)  | YES  |     | NULL    |       |
4September    | varchar(3)  | YES  |     | NULL    |       |
4October      | varchar(3)  | YES  |     | NULL    |       |
4January      | varchar(3)  | YES  |     | NULL    |       |
4February     | varchar(3)  | YES  |     | NULL    |       |
4March        | varchar(3)  | YES  |     | NULL    |       |
4FirstSemEnd  | varchar(3)  | YES  |     | NULL    |       |
4SecondSemEnd | varchar(3)  | YES  |     | NULL    |       |
*/


const attendenceTableColums=
[
"regdNo        ",
"1August       ",
"1September    ",
"1October      ",
"1January      ",
"1February     ",
"1March        ",
"1FirstSemEnd  ",
"1SecondSemEnd ",
"2August       ",
"2September    ",
"2October      ",
"2January      ",
"2February     ",
"2March        ",
"2FirstSemEnd  ",
"2SecondSemEnd ",
"3August       ",
"3September    ",
"3October      ",
"3January      ",
"3February     ",
"3March        ",
"3FirstSemEnd  ",
"3SecondSemEnd ",
"4August       ",
"4September    ",
"4October      ",
"4January      ",
"4February     ",
"4March        ",
"4FirstSemEnd  ",
"4SecondSemEnd "
]

module.exports=attendenceTableColums;
