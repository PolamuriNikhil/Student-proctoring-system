**password reset pending table correction**

 **sql config**
   SET @@global.sql_mode= '';
   it sets the max limit for uploads

