var student_data = [{
    name: "bean boy",
    regdNo: "00000001",
    section: "c",
    department: "cse"
},{
                                                                                                                          
//                                                             

    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000002",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000003",
    section: "c",
    department: "cse"
}
];
var faculty_data = [{
    name: "faculty faculty",
    regdNo: "Anit121"
},
{
    name: "faculty faculty",
    regdNo: "Anit122"
},
{
    name: "faculty faculty",
    regdNo: "Anit123"
},
{
    name: "faculty faculty",
    regdNo: "Anit124"
}
]
var Mapped_data = [{
    name: "bean boy",
    regdNo: "00000004",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000005",
    section: "c",
    department: "cse"
},
{
    name: "bean boy",
    regdNo: "00000006",
    section: "c",
    department: "cse"
}
];