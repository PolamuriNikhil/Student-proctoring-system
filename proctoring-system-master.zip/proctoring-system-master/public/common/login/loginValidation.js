const regex = {
    anitid: /^anil[0-9]{3}$/,
    password: /^[a-zA-Z0-9!@#\$%\^\&*\)\(+=._-]{6,}$/
}