/*
+-----------------+-------------+------+-----+---------+-------+
| Field           | Type        | Null | Key | Default | Extra |
+-----------------+-------------+------+-----+---------+-------+
| regdNo          | varchar(20) | NO   | PRI | NULL    |       |
| Issue111        | text        | YES  |     | NULL    |       |
| 111IssueFaculty | varchar(10) | YES  |     | NULL    |       |
| Issue112        | text        | YES  |     | NULL    |       |
| 112IssueFaculty | varchar(10) | YES  |     | NULL    |       |
| Issue121        | text        | YES  |     | NULL    |       |
| 121IssueFaculty | varchar(10) | YES  |     | NULL    |       |
| Issue122        | text        | YES  |     | NULL    |       |
| 122IssueFaculty | varchar(10) | YES  |     | NULL    |       |
| Issue211        | text        | YES  |     | NULL    |       |
| 211IssueFaculty | varchar(10) | YES  |     | NULL    |       |
| Issue212        | text        | YES  |     | NULL    |       |
| 212IssueFaculty | varchar(10) | YES  |     | NULL    |       |
| Issue221        | text        | YES  |     | NULL    |       |
| 221IssueFaculty | varchar(10) | YES  |     | NULL    |       |
| Issue222        | text        | YES  |     | NULL    |       |
| 222IssueFaculty | varchar(10) | YES  |     | NULL    |       |
| Issue311        | text        | YES  |     | NULL    |       |
| 311IssueFaculty | varchar(10) | YES  |     | NULL    |       |
| Issue312        | text        | YES  |     | NULL    |       |
| 312IssueFaculty | varchar(10) | YES  |     | NULL    |       |
| Issue321        | text        | YES  |     | NULL    |       |
| 321IssueFaculty | varchar(10) | YES  |     | NULL    |       |
| Issue322        | text        | YES  |     | NULL    |       |
| 322IssueFaculty | varchar(10) | YES  |     | NULL    |       |
| Issue411        | text        | YES  |     | NULL    |       |
| 411IssueFaculty | varchar(10) | YES  |     | NULL    |       |
| Issue412        | text        | YES  |     | NULL    |       |
| 412IssueFaculty | varchar(10) | YES  |     | NULL    |       |
| Issue421        | text        | YES  |     | NULL    |       |
| 421IssueFaculty | varchar(10) | YES  |     | NULL    |       |
| Issue422        | text        | YES  |     | NULL    |       |
| 422IssueFaculty | varchar(10) | YES  |     | NULL    |       |
+-----------------+-------------+------+-----+---------+-------+

*/